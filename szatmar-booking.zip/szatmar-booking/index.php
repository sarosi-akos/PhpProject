<?php
session_start();
require_once 'php/config/Database.php';
require_once 'php/models/Accommodation.php';
require_once 'php/models/Booking.php';
require_once 'php/models/Review.php';
require_once 'php/models/User.php';

$database = new Database();
$db = $database->getConnection();

$view = isset($_GET['view']) ? $_GET['view'] : 'home';
$search = isset($_GET['s']) ? trim($_GET['s']) : '';
$auth_mode = isset($_GET['auth']) ? $_GET['auth'] : 'login';

$reviewModel = new ReviewModel($db);
$userModel = new UserModel($db);
$error = "";

// 1. Regisztráció kezelése
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'register') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    if($userModel->findByEmail($email)) {
        $error = "Ez az e-mail cím már foglalt!";
    } else {
        $user_id = $userModel->create($name, $email, $password);
        if($user_id) {
            $_SESSION['user_id'] = $user_id;
            $_SESSION['user_name'] = $name;
            header("Location: index.php?view=home&welcome=1");
            exit;
        }
    }
}

// 2. Bejelentkezés kezelése
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $user = $userModel->findByEmail($email);
    
    if($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        header("Location: index.php?view=home");
        exit;
    } else {
        $error = "Hibás e-mail cím vagy jelszó!";
    }
}

// 3. Kijelentkezés
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    header("Location: index.php?view=home");
    exit;
}

// 4. Foglalás mentése
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'book') {
    if(!isset($_SESSION['user_id'])) {
        header("Location: index.php?view=auth&auth=login&msg=login_required");
        exit;
    }
    $bookingModel = new BookingModel($db);
    $data = (object)[
        'accommodationId' => $_POST['hotel_id'],
        'guestId' => $_SESSION['user_id'],
        'guestEmail' => $_POST['guest_email'],
        'guestPhone' => $_POST['guest_phone'],
        'checkIn' => $_POST['check_in'],
        'checkOut' => $_POST['check_out'],
        'totalPrice' => $_POST['total_price'],
        'status' => 'Függőben'
    ];
    $bookingModel->create($data);
    header("Location: index.php?view=bookings&success=1");
    exit;
}

// 5. Új szállás mentése
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_accommodation') {
    if(!isset($_SESSION['user_id'])) exit;
    $accModel = new Accommodation($db);
    $data = (object)[
        'name' => $_POST['name'],
        'description' => $_POST['description'],
        'location' => $_POST['location'],
        'price_per_night' => $_POST['price'],
        'image_url' => $_POST['image_url'] ?: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&q=80&w=800',
        'host_id' => $_SESSION['user_id']
    ];
    $accModel->create($data);
    header("Location: index.php?view=home&added=1");
    exit;
}

// 6. Foglalás törlése
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_booking') {
    $bookingId = $_POST['booking_id'];
    $stmt = $db->prepare("DELETE FROM bookings WHERE id = ? AND guest_id = ?");
    $stmt->execute([$bookingId, $_SESSION['user_id']]);
    header("Location: index.php?view=bookings&deleted=1");
    exit;
}

// 7. Értékelés mentése
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_review') {
    $data = (object)[
        'accommodationId' => $_POST['hotel_id'],
        'guestName' => $_SESSION['user_name'] ?? $_POST['guest_name'],
        'rating' => $_POST['rating'],
        'comment' => $_POST['comment']
    ];
    $reviewModel->create($data);
    header("Location: index.php?view=details&id=" . $_POST['hotel_id'] . "&review_success=1");
    exit;
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Szatmár Booking - Szálláskereső</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .rating-input input:checked ~ label,
        .rating-input label:hover,
        .rating-input label:hover ~ label { color: #f59e0b; }
        .rating-input label { color: #d1d5db; transition: color 0.2s; cursor: pointer; }
    </style>
</head>
<body class="bg-white text-gray-900 min-h-screen flex flex-col">

    <!-- Navbar -->
    <nav class="bg-white border-b sticky top-0 z-50 shadow-sm">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">
          <a href="index.php" class="flex items-center group">
            <i class="fa-solid fa-hotel text-rose-500 text-2xl mr-2 group-hover:scale-110 transition"></i>
            <span class="text-xl font-bold text-rose-500 tracking-tight">SzatmárBooking</span>
          </a>
          <div class="flex space-x-4 md:space-x-8">
            <a href="index.php?view=home" class="<?php echo $view === 'home' ? 'text-black border-b-2 border-rose-500' : 'text-gray-500'; ?> hover:text-black font-medium pb-1 transition-all">Főoldal</a>
            <?php if(isset($_SESSION['user_id'])): ?>
                <a href="index.php?view=bookings" class="<?php echo $view === 'bookings' ? 'text-black border-b-2 border-rose-500' : 'text-gray-500'; ?> hover:text-black font-medium pb-1 transition-all">Foglalásaim</a>
                <a href="index.php?view=host" class="<?php echo $view === 'host' ? 'text-black border-b-2 border-rose-500' : 'text-gray-500'; ?> hover:text-black font-medium pb-1 transition-all">Hirdetés feladása</a>
            <?php endif; ?>
          </div>
          <div class="flex items-center space-x-4">
            <?php if(isset($_SESSION['user_id'])): ?>
                <div class="flex items-center gap-3">
                    <span class="text-sm font-medium text-gray-700 hidden sm:block">Üdv, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</span>
                    <a href="index.php?action=logout" class="text-gray-500 hover:text-rose-500 transition text-sm font-bold">Kijelentkezés</a>
                </div>
            <?php else: ?>
                <a href="index.php?view=auth&auth=login" class="bg-rose-500 text-white px-5 py-2 rounded-full text-sm font-bold hover:bg-rose-600 transition shadow-lg shadow-rose-100">Bejelentkezés</a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </nav>

    <main class="max-w-7xl mx-auto px-4 py-8 flex-grow w-full">
        <?php if ($view === 'home'): ?>
            <!-- HOME VIEW -->
            <div class="mb-12 text-center">
                <h1 class="text-4xl font-extrabold text-gray-900 mb-4 tracking-tight">Fedezze fel Szatmár megye kincseit</h1>
                <form action="index.php" method="GET" class="max-w-2xl mx-auto bg-white shadow-xl rounded-full p-2 flex items-center border border-gray-200 focus-within:ring-2 focus-within:ring-rose-200 transition">
                    <input type="hidden" name="view" value="home">
                    <div class="flex-grow px-6">
                        <input type="text" name="s" placeholder="Hova utazna? (Szatmárnémeti, Nagykároly...)" class="w-full outline-none text-gray-700 bg-transparent" value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <button type="submit" class="bg-rose-500 text-white p-4 rounded-full hover:bg-rose-600 transition shadow-lg">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </form>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-6 gap-y-10">
                <?php
                $accModel = new Accommodation($db);
                $stmt = $accModel->readAll();
                $found = false;
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    if ($search) {
                        $searchLower = mb_strtolower($search, 'UTF-8');
                        $nameLower = mb_strtolower($row['name'], 'UTF-8');
                        $locationLower = mb_strtolower($row['location'], 'UTF-8');
                        if (strpos($nameLower, $searchLower) === false && strpos($locationLower, $searchLower) === false) continue;
                    }
                    $found = true;
                    $avg = $reviewModel->getAverageRating($row['id']);
                    ?>
                    <a href="index.php?view=details&id=<?php echo $row['id']; ?>" class="group">
                        <div class="relative aspect-square overflow-hidden rounded-xl bg-gray-200 shadow-sm border border-gray-100">
                            <img src="<?php echo $row['image_url']; ?>" class="h-full w-full object-cover group-hover:scale-105 transition duration-500" loading="lazy">
                        </div>
                        <div class="mt-3 flex justify-between">
                            <div>
                                <h3 class="text-sm font-bold text-gray-900"><?php echo $row['name']; ?></h3>
                                <p class="text-sm text-gray-500"><?php echo $row['location']; ?></p>
                                <p class="mt-1 font-bold text-gray-900"><?php echo number_format($row['price_per_night'], 0, ',', ' '); ?> RON <span class="text-gray-400 font-normal text-xs">/ éj</span></p>
                            </div>
                            <div class="flex items-start text-sm pt-0.5">
                                <i class="fa-solid fa-star text-rose-500 mr-1 text-[10px] mt-1"></i> 
                                <?php echo $avg['rating'] > 0 ? $avg['rating'] : 'Nincs még'; ?>
                            </div>
                        </div>
                    </a>
                <?php } 
                if (!$found): ?>
                    <div class="col-span-full text-center py-20 text-gray-500">
                        <i class="fa-solid fa-hotel text-4xl mb-4 block opacity-20"></i>
                        Nincs találat a következőre: "<?php echo htmlspecialchars($search); ?>"
                    </div>
                <?php endif; ?>
            </div>

        <?php elseif ($view === 'auth'): ?>
            <!-- AUTH VIEW (Login & Register) -->
            <div class="max-w-md mx-auto py-12">
                <div class="bg-white border rounded-3xl shadow-2xl overflow-hidden">
                    <div class="flex border-b">
                        <a href="index.php?view=auth&auth=login" class="flex-1 text-center py-4 font-bold <?php echo $auth_mode === 'login' ? 'bg-white text-rose-500' : 'bg-gray-50 text-gray-400'; ?>">Bejelentkezés</a>
                        <a href="index.php?view=auth&auth=register" class="flex-1 text-center py-4 font-bold <?php echo $auth_mode === 'register' ? 'bg-white text-rose-500' : 'bg-gray-50 text-gray-400'; ?>">Regisztráció</a>
                    </div>
                    <div class="p-8">
                        <?php if($error): ?>
                            <div class="bg-red-50 text-red-500 p-4 rounded-xl mb-6 text-sm font-medium border border-red-100">
                                <i class="fa-solid fa-circle-exclamation mr-2"></i> <?php echo $error; ?>
                            </div>
                        <?php endif; ?>

                        <?php if(isset($_GET['msg']) && $_GET['msg'] === 'login_required'): ?>
                            <div class="bg-yellow-50 text-yellow-700 p-4 rounded-xl mb-6 text-sm font-medium border border-yellow-100">
                                <i class="fa-solid fa-lock mr-2"></i> A foglaláshoz kérjük jelentkezzen be!
                            </div>
                        <?php endif; ?>

                        <form action="index.php" method="POST" class="space-y-5">
                            <input type="hidden" name="action" value="<?php echo $auth_mode; ?>">
                            
                            <?php if($auth_mode === 'register'): ?>
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Teljes név</label>
                                    <input type="text" name="name" required class="w-full border rounded-xl p-4 outline-none focus:ring-2 focus:ring-rose-500 bg-gray-50/50">
                                </div>
                            <?php endif; ?>

                            <div>
                                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">E-mail cím</label>
                                <input type="email" name="email" required class="w-full border rounded-xl p-4 outline-none focus:ring-2 focus:ring-rose-500 bg-gray-50/50">
                            </div>

                            <div>
                                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Jelszó</label>
                                <input type="password" name="password" required class="w-full border rounded-xl p-4 outline-none focus:ring-2 focus:ring-rose-500 bg-gray-50/50">
                            </div>

                            <button type="submit" class="w-full bg-rose-500 text-white py-4 rounded-2xl font-bold hover:bg-rose-600 transition shadow-xl shadow-rose-100 active:scale-95">
                                <?php echo $auth_mode === 'login' ? 'Bejelentkezés' : 'Fiók létrehozása'; ?>
                            </button>
                        </form>
                    </div>
                </div>
            </div>

        <?php elseif ($view === 'details'): ?>
            <!-- DETAILS VIEW -->
            <?php
            $id = isset($_GET['id']) ? $_GET['id'] : 0;
            $accModel = new Accommodation($db);
            $hotel = $accModel->readOne($id);
            if (!$hotel): echo "<div class='text-center py-20 text-gray-500'>Szállás nem található.</div>";
            else:
                $avg = $reviewModel->getAverageRating($id);
                $reviews = $reviewModel->getByAccommodation($id);
            ?>
            <div class="max-w-5xl mx-auto">
                <a href="index.php" class="mb-6 inline-flex items-center text-gray-600 hover:text-black transition font-medium">
                    <i class="fa-solid fa-chevron-left mr-2"></i> Vissza a kereséshez
                </a>
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
                    <div class="lg:col-span-2">
                        <div class="flex justify-between items-start mb-2">
                            <h2 class="text-4xl font-bold text-gray-900"><?php echo $hotel['name']; ?></h2>
                            <div class="flex items-center bg-gray-50 px-3 py-2 rounded-xl border">
                                <i class="fa-solid fa-star text-yellow-500 mr-2"></i>
                                <span class="font-bold text-lg"><?php echo $avg['rating']; ?></span>
                                <span class="text-gray-400 text-sm ml-1">(<?php echo $avg['count']; ?> vélemény)</span>
                            </div>
                        </div>
                        <p class="text-gray-500 mb-6 flex items-center font-medium"><i class="fa-solid fa-location-dot mr-2 text-rose-500"></i> <?php echo $hotel['location']; ?></p>
                        <img src="<?php echo $hotel['image_url']; ?>" class="w-full h-[450px] object-cover rounded-3xl shadow-xl mb-8 border border-gray-100">
                        
                        <div class="border-b border-gray-100 pb-8 mb-8">
                            <h3 class="text-2xl font-bold mb-4 text-gray-800">A szállásról</h3>
                            <p class="text-gray-600 leading-relaxed text-lg"><?php echo $hotel['description']; ?></p>
                        </div>

                        <!-- REVIEWS SECTION -->
                        <div class="mb-12">
                            <h3 class="text-2xl font-bold mb-8 text-gray-800 flex items-center gap-3">
                                <i class="fa-regular fa-comment-dots text-rose-500"></i>
                                Vélemények
                            </h3>
                            
                            <div class="space-y-6 mb-12">
                                <?php if (empty($reviews)): ?>
                                    <p class="text-gray-400 italic">Még nem érkezett vélemény ehhez a szálláshoz.</p>
                                <?php else: foreach($reviews as $r): ?>
                                    <div class="bg-gray-50 p-6 rounded-2xl border border-gray-100">
                                        <div class="flex justify-between items-center mb-4">
                                            <div>
                                                <span class="font-bold text-gray-900"><?php echo htmlspecialchars($r['guest_name']); ?></span>
                                                <div class="flex text-yellow-500 text-xs mt-1">
                                                    <?php for($i=1; $i<=5; $i++) echo $i <= $r['rating'] ? '<i class="fa-solid fa-star"></i>' : '<i class="fa-regular fa-star"></i>'; ?>
                                                </div>
                                            </div>
                                            <span class="text-xs text-gray-400"><?php echo date('Y.m.d', strtotime($r['created_at'])); ?></span>
                                        </div>
                                        <p class="text-gray-600 italic">"<?php echo htmlspecialchars($r['comment']); ?>"</p>
                                    </div>
                                <?php endforeach; endif; ?>
                            </div>

                            <!-- REVIEW FORM -->
                            <div class="bg-white border rounded-3xl p-8 shadow-sm">
                                <h4 class="text-xl font-bold mb-6">Írja meg véleményét</h4>
                                <form action="index.php" method="POST" class="space-y-4">
                                    <input type="hidden" name="action" value="add_review">
                                    <input type="hidden" name="hotel_id" value="<?php echo $hotel['id']; ?>">
                                    
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <label class="block text-xs font-bold text-gray-700 mb-1 uppercase">Az Ön neve</label>
                                            <input type="text" name="guest_name" value="<?php echo $_SESSION['user_name'] ?? ''; ?>" required placeholder="Gábor" class="w-full border rounded-xl p-3 outline-none focus:ring-2 focus:ring-rose-500 bg-gray-50/50" <?php echo isset($_SESSION['user_name']) ? 'readonly' : ''; ?>>
                                        </div>
                                        <div>
                                            <label class="block text-xs font-bold text-gray-700 mb-1 uppercase">Értékelés</label>
                                            <div class="flex items-center gap-1 rating-input text-2xl py-1">
                                                <input type="radio" name="rating" value="5" id="star5" class="hidden" required><label for="star5" title="5 csillag"><i class="fa-solid fa-star"></i></label>
                                                <input type="radio" name="rating" value="4" id="star4" class="hidden"><label for="star4" title="4 csillag"><i class="fa-solid fa-star"></i></label>
                                                <input type="radio" name="rating" value="3" id="star3" class="hidden"><label for="star3" title="3 csillag"><i class="fa-solid fa-star"></i></label>
                                                <input type="radio" name="rating" value="2" id="star2" class="hidden"><label for="star2" title="2 csillag"><i class="fa-solid fa-star"></i></label>
                                                <input type="radio" name="rating" value="1" id="star1" class="hidden"><label for="star1" title="1 csillag"><i class="fa-solid fa-star"></i></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-bold text-gray-700 mb-1 uppercase">Hozzászólás</label>
                                        <textarea name="comment" rows="3" required placeholder="Milyen volt az ott töltött idő?" class="w-full border rounded-xl p-3 outline-none focus:ring-2 focus:ring-rose-500 bg-gray-50/50 resize-none"></textarea>
                                    </div>
                                    <button type="submit" class="bg-black text-white px-8 py-3 rounded-xl font-bold hover:bg-gray-800 transition">Küldés</button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- BOOKING CARD (Sticky) -->
                    <div>
                        <div class="bg-white border border-gray-100 rounded-3xl shadow-2xl p-8 sticky top-24">
                            <div class="text-3xl font-bold mb-8"><?php echo number_format($hotel['price_per_night'], 0, ',', ' '); ?> RON <span class="text-base font-normal text-gray-500">/ éjszaka</span></div>
                            <form action="index.php" method="POST" class="space-y-4">
                                <input type="hidden" name="action" value="book">
                                <input type="hidden" name="hotel_id" value="<?php echo $hotel['id']; ?>">
                                <input type="hidden" name="total_price" value="<?php echo $hotel['price_per_night']; ?>">
                                
                                <div class="grid grid-cols-2 gap-2 mb-4">
                                    <div class="border rounded-xl p-3 bg-gray-50/50">
                                        <label class="block text-[10px] font-bold uppercase text-gray-500 mb-1">Érkezés</label>
                                        <input type="date" name="check_in" required class="w-full bg-transparent outline-none text-sm">
                                    </div>
                                    <div class="border rounded-xl p-3 bg-gray-50/50">
                                        <label class="block text-[10px] font-bold uppercase text-gray-500 mb-1">Távozás</label>
                                        <input type="date" name="check_out" required class="w-full bg-transparent outline-none text-sm">
                                    </div>
                                </div>

                                <div class="space-y-3">
                                    <div>
                                        <label class="block text-xs font-bold text-gray-700 mb-1">E-mail cím</label>
                                        <input type="email" name="guest_email" value="<?php echo $_SESSION['email'] ?? ''; ?>" placeholder="pelda@email.hu" required class="w-full border rounded-xl p-4 outline-none focus:ring-2 focus:ring-rose-500 transition bg-gray-50/30">
                                    </div>
                                    <div>
                                        <label class="block text-xs font-bold text-gray-700 mb-1">Telefonszám (Román)</label>
                                        <input type="tel" name="guest_phone" placeholder="0712345678" pattern="^(07[0-9]{8}|\+407[0-9]{8})$" title="Kérjük román telefonszámot adjon meg" required class="w-full border rounded-xl p-4 outline-none focus:ring-2 focus:ring-rose-500 transition bg-gray-50/30">
                                    </div>
                                </div>

                                <?php if(isset($_SESSION['user_id'])): ?>
                                    <button type="submit" class="w-full bg-rose-500 text-white py-4 rounded-2xl font-bold hover:bg-rose-600 transition shadow-xl shadow-rose-100 mt-6 active:scale-95">Lefoglalom most</button>
                                <?php else: ?>
                                    <a href="index.php?view=auth&auth=login&msg=login_required" class="w-full block text-center bg-gray-800 text-white py-4 rounded-2xl font-bold hover:bg-black transition shadow-xl mt-6">Bejelentkezés a foglaláshoz</a>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

        <?php elseif ($view === 'bookings'): ?>
            <!-- BOOKINGS VIEW -->
            <div class="max-w-4xl mx-auto">
                <h2 class="text-3xl font-bold mb-8">Foglalásaim</h2>
                <div class="space-y-6">
                    <?php
                    $stmt = $db->prepare("SELECT b.*, a.name, a.location, a.image_url FROM bookings b JOIN accommodations a ON b.accommodation_id = a.id WHERE b.guest_id = ? ORDER BY b.id DESC");
                    $stmt->execute([$_SESSION['user_id']]);
                    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    if (empty($bookings)): ?>
                        <div class="text-center py-20 bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200">
                            <i class="fa-regular fa-calendar-xmark text-5xl text-gray-300 mb-4"></i>
                            <p class="text-gray-500 text-lg">Még nincs aktív foglalása.</p>
                            <a href="index.php" class="mt-6 inline-block bg-rose-500 text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-rose-100 transition hover:bg-rose-600">Szállások keresése</a>
                        </div>
                    <?php else: 
                        foreach ($bookings as $b): ?>
                        <div class="bg-white p-6 rounded-3xl border border-gray-100 flex flex-col md:flex-row gap-6 hover:shadow-xl transition-all group relative">
                            <div class="w-full md:w-48 h-32 overflow-hidden rounded-2xl flex-shrink-0">
                                <img src="<?php echo $b['image_url']; ?>" class="w-full h-full object-cover group-hover:scale-110 transition duration-500">
                            </div>
                            <div class="flex-grow flex flex-col justify-between">
                                <div>
                                    <h3 class="text-xl font-bold group-hover:text-rose-500 transition"><?php echo $b['name']; ?></h3>
                                    <p class="text-sm text-gray-500 mb-3"><i class="fa-solid fa-location-dot mr-1"></i> <?php echo $b['location']; ?></p>
                                    <div class="flex flex-wrap gap-3">
                                        <div class="bg-gray-50 px-3 py-1.5 rounded-lg text-xs font-medium text-gray-600 border border-gray-100">
                                            <i class="fa-regular fa-calendar mr-1"></i> <?php echo $b['check_in']; ?> - <?php echo $b['check_out']; ?>
                                        </div>
                                        <div class="bg-gray-50 px-3 py-1.5 rounded-lg text-xs font-medium text-gray-600 border border-gray-100">
                                            <i class="fa-solid fa-phone mr-1 text-rose-400"></i> <?php echo $b['guest_phone']; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="flex flex-col justify-between items-end min-w-[140px]">
                                <form action="index.php" method="POST" onsubmit="return confirm('Biztosan törölni szeretné ezt a foglalást?')">
                                    <input type="hidden" name="action" value="delete_booking">
                                    <input type="hidden" name="booking_id" value="<?php echo $b['id']; ?>">
                                    <button type="submit" class="text-gray-300 hover:text-red-500 transition p-2 text-sm flex items-center gap-1 font-medium">
                                        <i class="fa-solid fa-trash-can"></i> Törlés
                                    </button>
                                </form>
                                <div class="text-right">
                                    <p class="text-[10px] font-bold text-gray-400 uppercase">Összesen</p>
                                    <p class="text-2xl font-extrabold text-rose-500"><?php echo number_format($b['total_price'], 0, ',', ' '); ?> RON</p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>

        <?php elseif ($view === 'host'): ?>
            <!-- HOST VIEW -->
            <div class="max-w-2xl mx-auto py-10">
                <div class="text-center mb-10">
                    <h2 class="text-3xl font-extrabold text-gray-900 mb-2">Hirdesse meg szálláshelyét!</h2>
                    <p class="text-gray-500">Csatlakozzon Szatmár megye legnagyobb szálláskereső közösségéhez.</p>
                </div>
                <div class="bg-white border border-gray-100 rounded-3xl shadow-2xl p-8 md:p-12">
                    <form action="index.php" method="POST" class="space-y-6">
                        <input type="hidden" name="action" value="add_accommodation">
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">Szálláshely neve</label>
                            <input type="text" name="name" required placeholder="Pl. Szatmári Panzió" class="w-full border-none bg-gray-50 rounded-2xl p-4 outline-none focus:ring-2 focus:ring-rose-500 transition">
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-2">Helyszín</label>
                                <input type="text" name="location" required placeholder="Pl. Szatmárnémeti" class="w-full border-none bg-gray-50 rounded-2xl p-4 outline-none focus:ring-2 focus:ring-rose-500 transition">
                            </div>
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-2">Ár / éjszaka (RON)</label>
                                <input type="number" name="price" required placeholder="200" class="w-full border-none bg-gray-50 rounded-2xl p-4 outline-none focus:ring-2 focus:ring-rose-500 transition">
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">Kép URL (opcionális)</label>
                            <input type="url" name="image_url" placeholder="https://..." class="w-full border-none bg-gray-50 rounded-2xl p-4 outline-none focus:ring-2 focus:ring-rose-500 transition">
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">Leírás</label>
                            <textarea name="description" required rows="4" placeholder="Írja le szálláshelye legfontosabb adottságait..." class="w-full border-none bg-gray-50 rounded-2xl p-4 outline-none focus:ring-2 focus:ring-rose-500 transition resize-none"></textarea>
                        </div>
                        <button type="submit" class="w-full bg-black text-white py-5 rounded-2xl font-bold hover:bg-gray-800 transition shadow-xl active:scale-95">Hirdetés közzététele</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <footer class="bg-gray-50 border-t py-12 mt-20">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex flex-col md:flex-row justify-between items-center gap-6">
                <div class="flex items-center">
                    <i class="fa-solid fa-hotel text-rose-500 text-xl mr-2"></i>
                    <span class="text-lg font-bold text-gray-900 tracking-tight text-rose-500">SzatmárBooking</span>
                </div>
                <div class="flex gap-8 text-sm text-gray-500 font-medium">
                    <a href="#" class="hover:text-rose-500 transition">Adatvédelem</a>
                    <a href="#" class="hover:text-rose-500 transition">Kapcsolat</a>
                    <a href="#" class="hover:text-rose-500 transition">GYIK</a>
                </div>
            </div>
            <div class="mt-10 pt-10 border-t border-gray-200 text-center">
                <p class="text-gray-400 text-[11px] uppercase tracking-widest font-bold">© 2024 Szatmár Booking • Satu Mare County Portal</p>
            </div>
        </div>
    </footer>

    <script>
        // Star rating behavior
        const labels = document.querySelectorAll('.rating-input label');
        const inputs = document.querySelectorAll('.rating-input input');
        
        inputs.forEach(input => {
            input.addEventListener('change', (e) => {
                const val = parseInt(e.target.value);
                labels.forEach((l, idx) => {
                    const lVal = 5 - idx;
                    l.querySelector('i').className = lVal <= val ? 'fa-solid fa-star' : 'fa-regular fa-star';
                });
            });
        });
    </script>

</body>
</html>