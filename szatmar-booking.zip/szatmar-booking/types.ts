export enum BookingStatus {
  PENDING = 'Függőben',
  PAID = 'Fizetve',
  CANCELLED = 'Lemondva'
}

export interface User {
  id: number;
  name: string;
  role: 'guest' | 'host';
}

export interface Review {
  id: number;
  userId: number;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Accommodation {
  id: number;
  name: string;
  location: string;
  pricePerNight: number;
  description: string;
  imageUrl: string;
  rating: number;
  reviews: Review[];
  amenities: string[];
  hostId: number;
}

export interface Booking {
  id: number;
  accommodationId: number;
  guestId: number;
  checkIn: string;
  checkOut: string;
  totalPrice: number;
  status: BookingStatus;
}