import React, { useState, useEffect, useMemo } from 'react';
import { createRoot } from 'react-dom/client';

// --- Típusok ---
interface Accommodation {
  id: number;
  name: string;
  location: string;
  pricePerNight: number;
  description: string;
  imageUrl: string;
  rating: number;
  amenities: string[];
}

interface Booking {
  id?: number;
  accommodationId: number;
  guestId: number;
  checkIn: string;
  checkOut: string;
  totalPrice: number;
  status: string;
}

// --- API Hívások (Relatív útvonalakkal a 404 ellen) ---
const API_URL = 'php/api.php';

const api = {
  getHotels: async (): Promise<Accommodation[]> => {
    try {
      const res = await fetch(`${API_URL}?action=getHotels`);
      if (!res.ok) throw new Error('Hiba a szerveroldalon');
      return await res.json();
    } catch (err) {
      console.error(err);
      return [];
    }
  },
  createBooking: async (data: Partial<Booking>) => {
    const res = await fetch(`${API_URL}?action=createBooking`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return await res.json();
  }
};

// --- Komponensek ---

const App = () => {
  const [view, setView] = useState<'home' | 'details' | 'bookings'>('home');
  const [hotels, setHotels] = useState<Accommodation[]>([]);
  const [selectedHotel, setSelectedHotel] = useState<Accommodation | null>(null);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [myBookings, setMyBookings] = useState<Booking[]>([]);

  // Dátumok a foglaláshoz
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');

  useEffect(() => {
    loadHotels();
  }, []);

  const loadHotels = async () => {
    setLoading(true);
    const data = await api.getHotels();
    setHotels(data);
    setLoading(false);
  };

  const filteredHotels = useMemo(() => {
    return hotels.filter(h => 
      h.name.toLowerCase().includes(search.toLowerCase()) || 
      h.location.toLowerCase().includes(search.toLowerCase())
    );
  }, [hotels, search]);

  const handleBooking = async () => {
    if (!selectedHotel || !checkIn || !checkOut) {
      alert('Kérjük töltsön ki minden mezőt!');
      return;
    }

    const start = new Date(checkIn);
    const end = new Date(checkOut);
    const nights = Math.max(1, Math.ceil((end.getTime() - start.getTime()) / (1000 * 3600 * 24)));
    
    const payload = {
      accommodationId: selectedHotel.id,
      guestId: 1,
      checkIn,
      checkOut,
      totalPrice: selectedHotel.pricePerNight * nights,
      status: 'Függőben'
    };

    const result = await api.createBooking(payload);
    if (result.id) {
      alert('Sikeres foglalás!');
      setMyBookings([...myBookings, { ...payload, id: result.id }]);
      setView('bookings');
    } else {
      alert('Hiba történt: ' + result.message);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Navbar */}
      <nav className="border-b px-8 py-4 flex justify-between items-center sticky top-0 bg-white z-50">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setView('home')}>
          <i className="fa-solid fa-hotel text-rose-500 text-2xl"></i>
          <span className="text-xl font-bold text-rose-500">SzatmárBooking</span>
        </div>
        <div className="flex gap-6 font-medium text-gray-600">
          <button onClick={() => setView('home')} className={view === 'home' ? 'text-black' : ''}>Kezdőlap</button>
          <button onClick={() => setView('bookings')} className={view === 'bookings' ? 'text-black' : ''}>Foglalásaim</button>
        </div>
        <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
          <i className="fa-solid fa-user text-gray-500"></i>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto p-8">
        {view === 'home' && (
          <>
            <div className="mb-10 flex flex-col items-center">
              <h1 className="text-3xl font-bold mb-6">Találja meg a tökéletes szállást Szatmár megyében</h1>
              <div className="w-full max-w-xl relative">
                <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                <input 
                  type="text" 
                  placeholder="Keresés (Pl. Szatmárnémeti, Nagykároly...)" 
                  className="w-full pl-12 pr-4 py-4 rounded-full border shadow-sm focus:outline-none focus:ring-2 focus:ring-rose-500"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
            </div>

            {loading ? (
              <div className="text-center py-20 text-gray-500">Szállások betöltése...</div>
            ) : (
              <div className="hotel-grid">
                {filteredHotels.map(hotel => (
                  <div key={hotel.id} className="group cursor-pointer" onClick={() => { setSelectedHotel(hotel); setView('details'); }}>
                    <div className="aspect-square rounded-xl overflow-hidden mb-3">
                      <img src={hotel.imageUrl} alt={hotel.name} className="w-full h-full object-cover group-hover:scale-105 transition" />
                    </div>
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-bold text-gray-900">{hotel.name}</h3>
                        <p className="text-gray-500 text-sm">{hotel.location}</p>
                        <p className="mt-1"><span className="font-bold">{hotel.pricePerNight} RON</span> / éj</p>
                      </div>
                      <div className="flex items-center gap-1 text-sm">
                        <i className="fa-solid fa-star text-yellow-500"></i>
                        <span>{hotel.rating}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {view === 'details' && selectedHotel && (
          <div className="max-w-4xl mx-auto">
            <button onClick={() => setView('home')} className="mb-6 text-gray-600 hover:underline">
              <i className="fa-solid fa-chevron-left mr-2"></i> Vissza a kereséshez
            </button>
            <h2 className="text-4xl font-bold mb-4">{selectedHotel.name}</h2>
            <div className="flex items-center gap-4 text-sm text-gray-600 mb-6">
              <span><i className="fa-solid fa-location-dot mr-1 text-rose-500"></i> {selectedHotel.location}</span>
              <span><i className="fa-solid fa-star text-yellow-500 mr-1"></i> {selectedHotel.rating}</span>
            </div>
            <img src={selectedHotel.imageUrl} className="w-full h-[450px] object-cover rounded-3xl mb-8 shadow-lg" alt="" />
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              <div className="md:col-span-2">
                <h3 className="text-2xl font-bold mb-4 border-b pb-4">Leírás</h3>
                <p className="text-gray-700 leading-relaxed mb-8">{selectedHotel.description}</p>
                <h3 className="text-2xl font-bold mb-4">Amit a szállás kínál</h3>
                <div className="grid grid-cols-2 gap-4">
                  {selectedHotel.amenities.map(a => (
                    <div key={a} className="flex items-center gap-2 text-gray-600">
                      <i className="fa-solid fa-check text-green-500"></i> {a}
                    </div>
                  ))}
                </div>
              </div>
              <div className="md:col-span-1">
                <div className="border rounded-2xl p-6 shadow-xl sticky top-24">
                  <div className="text-2xl font-bold mb-6">{selectedHotel.pricePerNight} RON <span className="text-base font-normal text-gray-500">/ éj</span></div>
                  <div className="space-y-4 mb-6">
                    <div>
                      <label className="block text-xs font-bold uppercase text-gray-500 mb-1">Érkezés</label>
                      <input type="date" value={checkIn} onChange={e => setCheckIn(e.target.value)} className="w-full border rounded-lg p-3 outline-none focus:ring-1 focus:ring-rose-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase text-gray-500 mb-1">Távozás</label>
                      <input type="date" value={checkOut} onChange={e => setCheckOut(e.target.value)} className="w-full border rounded-lg p-3 outline-none focus:ring-1 focus:ring-rose-500" />
                    </div>
                  </div>
                  <button onClick={handleBooking} className="w-full bg-rose-500 text-white font-bold py-4 rounded-xl hover:bg-rose-600 transition">Lefoglalom</button>
                  <p className="text-center text-xs text-gray-400 mt-4 italic">Fizetés a helyszínen történik</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {view === 'bookings' && (
          <div>
            <h2 className="text-3xl font-bold mb-8">Foglalásaim</h2>
            {myBookings.length === 0 ? (
              <div className="text-center py-20 bg-gray-50 rounded-3xl">
                <i className="fa-regular fa-calendar-xmark text-5xl text-gray-300 mb-4"></i>
                <p className="text-gray-500">Még nincs elmentett foglalása.</p>
                <button onClick={() => setView('home')} className="mt-6 bg-black text-white px-8 py-3 rounded-xl font-bold">Keresés indítása</button>
              </div>
            ) : (
              <div className="space-y-4">
                {myBookings.map((b, i) => (
                  <div key={i} className="border rounded-2xl p-6 flex justify-between items-center hover:shadow-md transition">
                    <div>
                      <h4 className="font-bold text-lg">Foglalás #{i + 1}</h4>
                      <p className="text-gray-600">{b.checkIn} - {b.checkOut}</p>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-rose-500 text-xl">{b.totalPrice} RON</div>
                      <div className="text-sm text-yellow-600 font-medium">{b.status}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      <footer className="border-t mt-20 py-10 bg-gray-50">
        <div className="max-w-7xl mx-auto px-8 text-center text-gray-400 text-sm">
          © 2024 Szatmár Booking. Minden jog fenntartva.
        </div>
      </footer>
    </div>
  );
};

const container = document.getElementById('root');
if (container) {
  const root = createRoot(container);
  root.render(<App />);
}
