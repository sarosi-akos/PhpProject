<?php
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../models/Accommodation.php';

class AccommodationController {
    public function getList() {
        try {
            $database = new Database();
            $db = $database->getConnection();
            
            if (!$db) {
                throw new Exception("Adatbázis hiba");
            }

            $hotelModel = new Accommodation($db);
            $stmt = $hotelModel->readAll();
            $num = $stmt->rowCount();

            if($num > 0) {
                $hotels_arr = array();
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    extract($row);
                    $hotel_item = array(
                        "id" => (int)$id,
                        "name" => $name,
                        "description" => $description,
                        "location" => $location,
                        "pricePerNight" => (float)$price_per_night,
                        "imageUrl" => $image_url,
                        "rating" => 4.5,
                        "amenities" => ["WiFi", "Parkoló", "Klíma", "TV"],
                        "reviews" => []
                    );
                    array_push($hotels_arr, $hotel_item);
                }
                http_response_code(200);
                echo json_encode($hotels_arr);
            } else {
                http_response_code(200);
                echo json_encode(array());
            }
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(array("message" => "Hiba: " . $e->getMessage()));
        }
    }
}
?>