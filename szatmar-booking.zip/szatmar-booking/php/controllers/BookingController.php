<?php
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../models/Booking.php';

class BookingController {
    public function save() {
        try {
            $database = new Database();
            $db = $database->getConnection();
            
            if (!$db) {
                throw new Exception("Adatbázis hiba");
            }

            $model = new BookingModel($db);
            $data = json_decode(file_get_contents("php://input"));

            if(!empty($data->accommodationId) && !empty($data->checkIn) && !empty($data->checkOut)) {
                $id = $model->create($data);
                if($id) {
                    http_response_code(201);
                    echo json_encode(array("message" => "Sikeres foglalás.", "id" => $id));
                } else {
                    http_response_code(503);
                    echo json_encode(array("message" => "Nem sikerült menteni a foglalást."));
                }
            } else {
                http_response_code(400);
                echo json_encode(array("message" => "Hiányzó adatok (accommodationId, checkIn, checkOut)."));
            }
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(array("message" => "Szerver hiba: " . $e->getMessage()));
        }
    }
}
?>