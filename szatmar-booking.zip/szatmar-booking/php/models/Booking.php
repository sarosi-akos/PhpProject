<?php
class BookingModel {
    private $conn;
    private $table_name = "bookings";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($data) {
        $query = "INSERT INTO " . $this->table_name . " 
                (accommodation_id, guest_id, guest_email, guest_phone, check_in, check_out, total_price, status) 
                VALUES (:accommodation_id, :guest_id, :guest_email, :guest_phone, :check_in, :check_out, :total_price, :status)";
        
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':accommodation_id', $data->accommodationId);
        $stmt->bindParam(':guest_id', $data->guestId);
        $stmt->bindParam(':guest_email', $data->guestEmail);
        $stmt->bindParam(':guest_phone', $data->guestPhone);
        $stmt->bindParam(':check_in', $data->checkIn);
        $stmt->bindParam(':check_out', $data->checkOut);
        $stmt->bindParam(':total_price', $data->totalPrice);
        $stmt->bindParam(':status', $data->status);

        if($stmt->execute()) {
            return $this->conn->lastInsertId();
        }
        return false;
    }
}
?>