<?php
class ReviewModel {
    private $conn;
    private $table_name = "reviews";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($data) {
        $query = "INSERT INTO " . $this->table_name . " 
                (accommodation_id, guest_name, rating, comment) 
                VALUES (:accommodation_id, :guest_name, :rating, :comment)";
        
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':accommodation_id', $data->accommodationId);
        $stmt->bindParam(':guest_name', $data->guestName);
        $stmt->bindParam(':rating', $data->rating);
        $stmt->bindParam(':comment', $data->comment);

        return $stmt->execute();
    }

    public function getByAccommodation($accommodation_id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE accommodation_id = ? ORDER BY created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $accommodation_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAverageRating($accommodation_id) {
        $query = "SELECT AVG(rating) as avg_rating, COUNT(*) as count FROM " . $this->table_name . " WHERE accommodation_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $accommodation_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['avg_rating'] ? [
            'rating' => round($row['avg_rating'], 1),
            'count' => $row['count']
        ] : ['rating' => 0, 'count' => 0];
    }
}
?>