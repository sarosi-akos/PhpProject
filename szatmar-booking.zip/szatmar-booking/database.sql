
CREATE DATABASE IF NOT EXISTS szatmar_booking CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE szatmar_booking;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('guest', 'host') DEFAULT 'guest',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS accommodations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    location VARCHAR(100) NOT NULL,
    price_per_night DECIMAL(10, 2) NOT NULL,
    image_url VARCHAR(255),
    host_id INT,
    FOREIGN KEY (host_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    accommodation_id INT NOT NULL,
    guest_id INT NOT NULL,
    guest_email VARCHAR(150) NOT NULL,
    guest_phone VARCHAR(20) NOT NULL,
    check_in DATE NOT NULL,
    check_out DATE NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'Függőben',
    FOREIGN KEY (accommodation_id) REFERENCES accommodations(id) ON DELETE CASCADE,
    FOREIGN KEY (guest_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    accommodation_id INT NOT NULL,
    guest_name VARCHAR(100) NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (accommodation_id) REFERENCES accommodations(id) ON DELETE CASCADE
);

-- Alapadatok visszatöltése valós képekkel
INSERT INTO accommodations (name, location, price_per_night, description, image_url) 
SELECT * FROM (
    SELECT 'Hotel Dana I', 'Szatmárnémeti', 220, 'Elegáns szálloda a város szívében, kiváló étteremmel és wellness részleggel.', 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=800' UNION ALL
    SELECT 'Hotel Aurora', 'Szatmárnémeti', 180, 'Klasszikus kényelem és barátságos kiszolgálás a központban.', 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&q=80&w=800' UNION ALL
    SELECT 'Hotel Cardinal', 'Szatmárnémeti', 250, 'Modern design és luxus lakosztályok igényes utazóknak.', 'https://images.unsplash.com/photo-1551882547-ff43c636f719?auto=format&fit=crop&q=80&w=800'
) AS tmp
WHERE NOT EXISTS (SELECT name FROM accommodations LIMIT 1);
