
<?php
/**
 * Ez a fájl segít megérteni, hogyan építsd fel a PHP backendet a React frontend mellé.
 * Kövesd az MVC és OOP alapelveket a PHPStormban.
 */

// 1. Model (OOP - Adatbázis kezelés)
class AccommodationModel {
    private $db;
    public function __construct($db) { $this->db = $db; }

    public function getAll() {
        $stmt = $this->db->query("SELECT * FROM accommodations");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// 2. Controller (Üzleti logika)
class BookingController {
    public function create() {
        // REST API bemenet olvasása
        $data = json_decode(file_get_contents("php://input"));
        // ... validáció és mentés ...
        echo json_encode(["status" => "success", "id" => 123]);
    }
}

// 3. Router / API Entry point (index.php)
// header("Content-Type: application/json");
// $method = $_SERVER['REQUEST_METHOD'];
// if ($method == 'GET') { /* Accommodations listing */ }
// if ($method == 'POST') { /* Booking creation */ }
?>
