
import React from 'react';
import { Accommodation } from '../types';

interface HotelCardProps {
  hotel: Accommodation;
  onClick: (hotel: Accommodation) => void;
}

const HotelCard: React.FC<HotelCardProps> = ({ hotel, onClick }) => {
  return (
    <div
      onClick={() => onClick(hotel)}
      className="group cursor-pointer transition-transform duration-200"
    >
      <div className="relative aspect-square overflow-hidden rounded-xl bg-gray-200">
        <img
          src={hotel.imageUrl}
          alt={hotel.name}
          className="h-full w-full object-cover group-hover:scale-110 transition-transform duration-300"
        />
        <button className="absolute top-3 right-3 p-2 bg-white/70 hover:bg-white rounded-full">
           <i className="fa-regular fa-heart text-gray-700"></i>
        </button>
      </div>
      <div className="mt-2 flex justify-between">
        <div>
          <h3 className="text-sm font-semibold text-gray-900">{hotel.name}</h3>
          <p className="text-sm text-gray-500">{hotel.location}</p>
          <div className="mt-1 flex items-center">
             <span className="font-semibold">{hotel.pricePerNight} RON</span>
             <span className="text-gray-500 text-sm ml-1">éjszaka</span>
          </div>
        </div>
        <div className="flex items-center">
           <i className="fa-solid fa-star text-xs mr-1 text-yellow-500"></i>
           <span className="text-sm font-medium">{hotel.rating}</span>
        </div>
      </div>
    </div>
  );
};

export default HotelCard;
