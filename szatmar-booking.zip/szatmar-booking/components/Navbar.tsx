import React from 'react';

interface NavbarProps {
  onMenuClick: (view: 'home' | 'bookings' | 'host') => void;
  activeView: string;
}

const Navbar: React.FC<NavbarProps> = ({ onMenuClick, activeView }) => {
  return (
    <nav className="bg-white border-b sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center cursor-pointer" onClick={() => onMenuClick('home')}>
            <i className="fa-solid fa-hotel text-rose-500 text-3xl mr-2"></i>
            <span className="text-xl font-bold text-rose-500 tracking-tight text-rose-500">SzatmárBooking</span>
          </div>

          <div className="hidden md:flex space-x-8">
            <button
              onClick={() => onMenuClick('home')}
              className={`${activeView === 'home' ? 'text-black border-b-2 border-rose-500' : 'text-gray-500'} hover:text-black font-medium pb-1 transition-all`}
            >
              Főoldal
            </button>
            <button
              onClick={() => onMenuClick('bookings')}
              className={`${activeView === 'bookings' ? 'text-black border-b-2 border-rose-500' : 'text-gray-500'} hover:text-black font-medium pb-1 transition-all`}
            >
              Foglalásaim
            </button>
            <button
              onClick={() => onMenuClick('host')}
              className={`${activeView === 'host' ? 'text-black border-b-2 border-rose-500' : 'text-gray-500'} hover:text-black font-medium pb-1 transition-all`}
            >
              Hirdetés feladása
            </button>
          </div>

          <div className="flex items-center space-x-4">
            <button className="p-2 rounded-full hover:bg-gray-100 relative">
               <i className="fa-solid fa-bell text-gray-600"></i>
            </button>
            <div className="w-8 h-8 rounded-full bg-rose-500 flex items-center justify-center text-white font-bold">
              U
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;