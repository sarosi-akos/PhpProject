import { Accommodation, Booking, BookingStatus } from '../types';

// Győződj meg róla, hogy a mappád neve pontosan ez a htdocs-ban!
const API_URL = 'http://localhost/szatmar_booking/php/api.php';

export const getAccommodations = async (): Promise<Accommodation[]> => {
  try {
    const response = await fetch(`${API_URL}?action=getHotels`);
    if (!response.ok) throw new Error('Hiba a letöltéskor');
    return await response.json();
  } catch (error) {
    console.error("API Error:", error);
    return [];
  }
};

export const createBooking = async (bookingData: Partial<Booking>): Promise<Booking> => {
  try {
    const response = await fetch(`${API_URL}?action=createBooking`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...bookingData,
        status: bookingData.status || BookingStatus.PENDING
      })
    });
    
    if (!response.ok) throw new Error('Szerver hiba a foglaláskor');
    
    const result = await response.json();
    return {
      ...bookingData,
      id: result.id,
      status: BookingStatus.PENDING
    } as Booking;
  } catch (error) {
    console.error("Booking Error:", error);
    throw error;
  }
};
