import React, { useState, useEffect, useMemo } from 'react';
import { Accommodation, Booking, BookingStatus } from './types';
import { getAccommodations, createBooking } from './services/api';
import Navbar from './components/Navbar';
import HotelCard from './components/HotelCard';

const App: React.FC = () => {
  const [view, setView] = useState<'home' | 'bookings' | 'host' | 'details'>('home');
  const [hotels, setHotels] = useState<Accommodation[]>([]);
  const [selectedHotel, setSelectedHotel] = useState<Accommodation | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const data = await getAccommodations();
      setHotels(data);
      setLoading(false);
    };
    fetchData();
  }, []);

  const filteredHotels = useMemo(() => {
    return hotels.filter(h =>
      h.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.location.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [hotels, searchQuery]);

  const handleBook = async () => {
    if (!selectedHotel || !checkIn || !checkOut) {
      alert('Kérjük töltsön ki minden adatot a foglaláshoz!');
      return;
    }

    try {
      const diff = new Date(checkOut).getTime() - new Date(checkIn).getTime();
      const days = Math.max(1, Math.ceil(diff / (1000 * 3600 * 24)));

      const bookingPayload: Partial<Booking> = {
        accommodationId: selectedHotel.id,
        guestId: 1, // Példa felhasználó ID
        checkIn,
        checkOut,
        totalPrice: selectedHotel.pricePerNight * days,
        status: BookingStatus.PENDING
      };

      const newBooking = await createBooking(bookingPayload);
      setBookings(prev => [...prev, newBooking]);
      alert('Foglalás sikeresen elmentve az adatbázisba!');
      setView('bookings');
    } catch (error) {
      console.error(error);
      alert('Hiba történt a foglalás során. Ellenőrizze a XAMPP-ot és az adatbázist!');
    }
  };

  const renderHome = () => (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-12 text-center">
        <h1 className="text-4xl font-extrabold text-gray-900 mb-4 tracking-tight">Fedezze fel Szatmár megye kincseit</h1>
        <div className="max-w-2xl mx-auto bg-white shadow-xl rounded-full p-2 flex items-center border border-gray-200">
           <div className="flex-grow px-6">
             <input
               type="text"
               placeholder="Hova utazna? (Szatmárnémeti, Nagykároly...)"
               className="w-full outline-none text-gray-700 bg-transparent"
               value={searchQuery}
               onChange={(e) => setSearchQuery(e.target.value)}
             />
           </div>
           <button className="bg-rose-500 text-white p-4 rounded-full hover:bg-rose-600 transition">
              <i className="fa-solid fa-magnifying-glass"></i>
           </button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-500"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-6 gap-y-10">
          {filteredHotels.map(hotel => (
            <HotelCard
              key={hotel.id}
              hotel={hotel}
              onClick={(h) => {
                setSelectedHotel(h);
                setView('details');
              }}
            />
          ))}
        </div>
      )}
    </div>
  );

  const renderDetails = () => {
    if (!selectedHotel) return null;
    return (
      <div className="max-w-5xl mx-auto px-4 py-8">
        <button
          onClick={() => setView('home')}
          className="mb-6 flex items-center text-gray-600 hover:text-black transition font-medium"
        >
          <i className="fa-solid fa-arrow-left mr-2"></i> Vissza a kereséshez
        </button>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            <h2 className="text-3xl font-bold mb-2 text-gray-900">{selectedHotel.name}</h2>
            <div className="flex items-center text-sm text-gray-600 mb-4">
               <i className="fa-solid fa-location-dot mr-1"></i> {selectedHotel.location}
               <span className="mx-2 text-gray-300">•</span>
               <i className="fa-solid fa-star text-yellow-500 mr-1"></i> {selectedHotel.rating}
            </div>

            <div className="rounded-2xl overflow-hidden mb-6 h-96 shadow-md border border-gray-100">
               <img src={selectedHotel.imageUrl} className="w-full h-full object-cover" alt={selectedHotel.name} />
            </div>

            <div className="border-b pb-6 mb-6">
              <h3 className="text-xl font-bold mb-3 text-gray-800">Leírás</h3>
              <p className="text-gray-600 leading-relaxed">{selectedHotel.description}</p>
            </div>

            <div>
              <h3 className="text-xl font-bold mb-3 text-gray-800">Szolgáltatások</h3>
              <div className="grid grid-cols-2 gap-4">
                {selectedHotel.amenities.map(a => (
                  <div key={a} className="flex items-center text-gray-700 bg-white p-2 rounded-lg border border-gray-50">
                    <i className="fa-solid fa-check text-green-500 mr-2"></i> {a}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="md:col-span-1">
            <div className="bg-white border rounded-2xl shadow-xl p-6 sticky top-24">
              <div className="flex justify-between items-center mb-6">
                <div>
                   <span className="text-2xl font-bold">{selectedHotel.pricePerNight} RON</span>
                   <span className="text-gray-500 ml-1 font-normal">/ éj</span>
                </div>
              </div>

              <div className="space-y-4 mb-6">
                <div className="border rounded-lg p-3">
                   <label className="block text-[10px] font-bold uppercase text-gray-500 tracking-wider">Érkezés</label>
                   <input
                     type="date"
                     className="w-full outline-none text-sm bg-transparent"
                     value={checkIn}
                     onChange={(e) => setCheckIn(e.target.value)}
                   />
                </div>
                <div className="border rounded-lg p-3">
                   <label className="block text-[10px] font-bold uppercase text-gray-500 tracking-wider">Távozás</label>
                   <input
                     type="date"
                     className="w-full outline-none text-sm bg-transparent"
                     value={checkOut}
                     onChange={(e) => setCheckOut(e.target.value)}
                   />
                </div>
              </div>

              <button
                onClick={handleBook}
                className="w-full bg-rose-500 text-white py-3 rounded-xl font-bold hover:bg-rose-600 transition shadow-lg shadow-rose-200 active:scale-[0.98]"
              >
                Lefoglalom
              </button>

              <p className="text-center text-xs text-gray-400 mt-4 italic">Az adatok közvetlenül az adatbázisba kerülnek mentésre.</p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderBookings = () => (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <h2 className="text-3xl font-bold mb-8 text-gray-900">Foglalásaim</h2>
      {bookings.length === 0 ? (
        <div className="bg-white p-16 rounded-3xl border border-gray-100 text-center shadow-sm">
           <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="fa-regular fa-calendar-xmark text-4xl text-gray-300"></i>
           </div>
           <p className="text-gray-500 text-lg">Még nincs aktív foglalásod.</p>
           <button onClick={() => setView('home')} className="mt-6 inline-block bg-black text-white px-8 py-3 rounded-xl font-bold hover:bg-gray-800 transition">
              Böngésszen a szállások között
           </button>
        </div>
      ) : (
        <div className="space-y-6">
          {bookings.map(b => {
            const hotel = hotels.find(h => h.id === Number(b.accommodationId));
            return (
              <div key={b.id} className="bg-white p-6 rounded-2xl border border-gray-100 flex flex-col md:flex-row gap-6 hover:shadow-lg transition-shadow duration-300">
                <img src={hotel?.imageUrl || 'https://via.placeholder.com/150'} className="w-full md:w-32 h-32 object-cover rounded-xl" alt="hotel" />
                <div className="flex-grow">
                   <h3 className="text-xl font-bold text-gray-900">{hotel?.name || 'Választott szállás'}</h3>
                   <p className="text-gray-500 text-sm mb-3 flex items-center">
                      <i className="fa-solid fa-location-dot mr-1 text-rose-400"></i> {hotel?.location || 'Ismeretlen helyszín'}
                   </p>
                   <div className="flex flex-wrap gap-4 text-sm font-medium text-gray-600">
                      <span className="bg-gray-50 px-3 py-1 rounded-md"><i className="fa-regular fa-calendar mr-2 text-rose-500"></i> Érkezés: <span className="text-gray-900">{b.checkIn}</span></span>
                      <span className="bg-gray-50 px-3 py-1 rounded-md"><i className="fa-regular fa-calendar mr-2 text-rose-500"></i> Távozás: <span className="text-gray-900">{b.checkOut}</span></span>
                   </div>
                </div>
                <div className="flex flex-col justify-between items-end border-l border-gray-50 pl-6 md:min-w-[120px]">
                   <span className={`px-3 py-1 rounded-full text-xs font-bold ${b.status === BookingStatus.PAID ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                      {b.status}
                   </span>
                   <div className="text-right">
                      <p className="text-gray-400 text-[10px] uppercase font-bold tracking-wider mb-1">Fizetendő</p>
                      <span className="text-2xl font-black text-rose-600">{b.totalPrice} RON</span>
                   </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );

  const renderHost = () => (
    <div className="max-w-2xl mx-auto px-4 py-12">
      <div className="text-center mb-10">
         <h2 className="text-3xl font-bold mb-2 text-gray-900">Hirdesd meg szállásod Szatmárban!</h2>
         <p className="text-gray-500">Csatlakozzon közösségünkhöz és fogadjon vendégeket a megye minden pontjáról.</p>
      </div>
      <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-xl shadow-gray-100/50">
         <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); alert('Mentve! A moderátorok hamarosan jóváhagyják a hirdetést.'); setView('home'); }}>
            <div>
               <label className="block text-sm font-bold mb-2 text-gray-700">Szálláshely neve</label>
               <input type="text" required className="w-full p-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-rose-500 transition" placeholder="Pl. Szatmári Panzió" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                 <label className="block text-sm font-bold mb-2 text-gray-700">Helyszín</label>
                 <input type="text" required className="w-full p-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-rose-500 transition" placeholder="Pl. Szatmárnémeti" />
              </div>
              <div>
                 <label className="block text-sm font-bold mb-2 text-gray-700">Ár / éjszaka (RON)</label>
                 <input type="number" required className="w-full p-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-rose-500 transition" placeholder="150" />
              </div>
            </div>
            <div>
               <label className="block text-sm font-bold mb-2 text-gray-700">Leírás</label>
               <textarea required rows={4} className="w-full p-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-rose-500 transition" placeholder="Részletezze szálláshelye adottságait..."></textarea>
            </div>
            <button type="submit" className="w-full bg-black text-white py-4 rounded-2xl font-bold hover:bg-gray-800 transition shadow-lg shadow-gray-200 active:scale-[0.99]">
               Hirdetés beküldése
            </button>
         </form>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-white">
      <Navbar onMenuClick={setView} activeView={view} />
      <main className="transition-all duration-300">
        {view === 'home' && renderHome()}
        {view === 'details' && renderDetails()}
        {view === 'bookings' && renderBookings()}
        {view === 'host' && renderHost()}
      </main>
      <footer className="bg-gray-50 border-t py-16 mt-20">
        <div className="max-w-7xl mx-auto px-4">
           <div className="flex flex-col md:flex-row justify-between items-center gap-8">
              <div className="flex items-center">
                 <i className="fa-solid fa-hotel text-rose-500 text-2xl mr-2"></i>
                 <span className="text-lg font-bold text-gray-900 tracking-tight">SzatmárBooking</span>
              </div>
              <div className="text-gray-500 text-sm flex gap-6">
                 <a href="#" className="hover:text-rose-500 transition">Adatvédelem</a>
                 <a href="#" className="hover:text-rose-500 transition">ÁSZF</a>
                 <a href="#" className="hover:text-rose-500 transition">Kapcsolat</a>
              </div>
           </div>
           <div className="mt-10 pt-10 border-t border-gray-100 text-center">
              <p className="text-gray-400 text-xs">© 2024 Szatmár Booking. Minden jog fenntartva. Satu Mare • Nagykároly • Tasnád • Avasfelsőfalu • Ardud • Sárköz</p>
           </div>
        </div>
      </footer>
    </div>
  );
};

export default App;